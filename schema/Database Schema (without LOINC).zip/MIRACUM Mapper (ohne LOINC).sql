--
-- PostgreSQL database dump
--

-- Dumped from database version 10.10 (Ubuntu 10.10-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 11.2

-- Started on 2020-01-08 13:43:53

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 2925 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 196 (class 1259 OID 16388)
-- Name: expertlevel; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.expertlevel (
    level integer NOT NULL,
    description character varying NOT NULL
);


ALTER TABLE public.expertlevel OWNER TO mapper;

--
-- TOC entry 2927 (class 0 OID 0)
-- Dependencies: 196
-- Name: TABLE expertlevel; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.expertlevel IS 'Defines the names of the states.';


--
-- TOC entry 2928 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN expertlevel.level; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.expertlevel.level IS 'The level.';


--
-- TOC entry 2929 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN expertlevel.description; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.expertlevel.description IS 'Describes the level.';


--
-- TOC entry 197 (class 1259 OID 16394)
-- Name: log; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.log (
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    text character varying(4000),
    ip character varying DEFAULT inet_client_addr()
);


ALTER TABLE public.log OWNER TO mapper;

--
-- TOC entry 2931 (class 0 OID 0)
-- Dependencies: 197
-- Name: TABLE log; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.log IS 'Stores the program log.';


--
-- TOC entry 2932 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN log."timestamp"; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.log."timestamp" IS 'The timestamp indicating when the entry was saved.';


--
-- TOC entry 2933 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN log.text; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.log.text IS 'The actual logging text.';


--
-- TOC entry 2934 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN log.ip; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.log.ip IS 'The IP address of the user''s computer.';


--
-- TOC entry 198 (class 1259 OID 16402)
-- Name: mapping; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.mapping (
    source_code character varying(50),
    target_code character varying(50),
    sec_source_code character varying(50),
    sec_source_code_cond character varying(50),
    documentation character varying(2000),
    mapping_level integer,
    version integer,
    deleted integer,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    saved_by character varying,
    sw_version character varying
);


ALTER TABLE public.mapping OWNER TO mapper;

--
-- TOC entry 2936 (class 0 OID 0)
-- Dependencies: 198
-- Name: TABLE mapping; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.mapping IS 'Stores the actual mappings.';


--
-- TOC entry 2937 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.source_code; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.source_code IS 'The code of the source terminology.';


--
-- TOC entry 2938 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.target_code; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.target_code IS 'The code of the target terminology.';


--
-- TOC entry 2939 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.sec_source_code; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.sec_source_code IS 'The secondary code from the source terminology, not yet defined or implemented.';


--
-- TOC entry 2940 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.sec_source_code_cond; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.sec_source_code_cond IS 'The condition associated with the secondary code. Not yet defined or implemented.';


--
-- TOC entry 2941 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.documentation; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.documentation IS 'The documentation text / history.';


--
-- TOC entry 2942 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.mapping_level; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.mapping_level IS 'The current mapping state.';


--
-- TOC entry 2943 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.version; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.version IS 'The version of the mapping.';


--
-- TOC entry 2944 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.deleted; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.deleted IS 'Specifies whether the mapping is deleted (=1) or active (=0).';


--
-- TOC entry 2945 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping."timestamp"; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping."timestamp" IS 'The timestamp indicating when the mapping was saved.';


--
-- TOC entry 2946 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.saved_by; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.saved_by IS 'Specifies which user saved the mapping.';


--
-- TOC entry 2947 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN mapping.sw_version; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.mapping.sw_version IS 'Specifies which software version of the tool saved the mapping.';


--
-- TOC entry 201 (class 1259 OID 16424)
-- Name: userids; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.userids (
    userid character varying NOT NULL,
    filterfrom integer DEFAULT 0,
    filterto integer DEFAULT 5,
    allowbrowsehistory boolean DEFAULT false,
    forcedfilter character varying,
    enabled boolean DEFAULT false,
    transitions character varying
);


ALTER TABLE public.userids OWNER TO mapper;

--
-- TOC entry 2949 (class 0 OID 0)
-- Dependencies: 201
-- Name: TABLE userids; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.userids IS 'Administration of users and their rights.';


--
-- TOC entry 2950 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.userid; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.userid IS 'The ID of the user, which is also used for login via LDAP.';


--
-- TOC entry 2951 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.filterfrom; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.filterfrom IS 'The default filter level (from table "expertlevel"), which is displayed under "From:" in the GUI at program start.';


--
-- TOC entry 2952 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.filterto; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.filterto IS 'The default filter level (from table "expertlevel"), which is displayed under "To:" in the GUI at program start.';


--
-- TOC entry 2953 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.allowbrowsehistory; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.allowbrowsehistory IS 'If "true", the version history of a mapping may be browsed.';


--
-- TOC entry 2954 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.forcedfilter; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.forcedfilter IS 'An additional filter that is applied to the "sourceterms" table when loading the source terminology. This can be used to control that a user does not see all source code. Example: source_code like ''6%''.';


--
-- TOC entry 2955 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.enabled; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.enabled IS 'If "true", the user is enabled for use.';


--
-- TOC entry 2956 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN userids.transitions; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.userids.transitions IS 'Defines the state transitions for the user.';

--
-- TOC entry 199 (class 1259 OID 16409)
-- Name: requiresversion; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.requiresversion (
    requiresversion integer
);


ALTER TABLE public.requiresversion OWNER TO mapper;

--
-- TOC entry 2958 (class 0 OID 0)
-- Dependencies: 199
-- Name: TABLE requiresversion; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.requiresversion IS 'Invalidates older program versions if the database schema has changed in such a way that the old program versions are no longer compatible.';


--
-- TOC entry 2959 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN requiresversion.requiresversion; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.requiresversion.requiresversion IS 'The schema version that the client program must support.';


--
-- TOC entry 202 (class 1259 OID 16449)
-- Name: sourceterms; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.sourceterms (
    source_code character varying(50),
    source_desc character varying(500)
);


ALTER TABLE public.sourceterms OWNER TO mapper;

--
-- TOC entry 2961 (class 0 OID 0)
-- Dependencies: 202
-- Name: TABLE sourceterms; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.sourceterms IS 'Stores the complete local terminology to be mapped to a standard.';


--
-- TOC entry 2962 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN sourceterms.source_code; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.sourceterms.source_code IS 'The code from the source terminology.';


--
-- TOC entry 2963 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN sourceterms.source_desc; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.sourceterms.source_desc IS 'The description of the code.';


--
-- TOC entry 200 (class 1259 OID 16418)
-- Name: terminfo; Type: TABLE; Schema: public; Owner: mapper
--

CREATE TABLE public.terminfo (
    code character varying(50),
    description character varying(500)
);


ALTER TABLE public.terminfo OWNER TO mapper;

--
-- TOC entry 2965 (class 0 OID 0)
-- Dependencies: 200
-- Name: TABLE terminfo; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON TABLE public.terminfo IS 'Used to look up target codes entered by the user in the "Target Code" field (top right) during mapping.';


--
-- TOC entry 2966 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN terminfo.code; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.terminfo.code IS 'The code from the target terminology.';


--
-- TOC entry 2967 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN terminfo.description; Type: COMMENT; Schema: public; Owner: mapper
--

COMMENT ON COLUMN public.terminfo.description IS 'The description of the code.';


--
-- TOC entry 2913 (class 0 OID 16388)
-- Dependencies: 196
-- Data for Name: expertlevel; Type: TABLE DATA; Schema: public; Owner: mapper
--

INSERT INTO public.expertlevel VALUES (0, 'Ungemappt');
INSERT INTO public.expertlevel VALUES (1, 'Zum Überarbeiten (Exp.)');
INSERT INTO public.expertlevel VALUES (3, 'Gemappt (Experte)');
INSERT INTO public.expertlevel VALUES (4, 'In Bearbeitung (Labor)');
INSERT INTO public.expertlevel VALUES (5, 'Validiert (Labor)');
INSERT INTO public.expertlevel VALUES (2, 'In Bearbeitung (Experte)');


--
-- TOC entry 2916 (class 0 OID 16409)
-- Dependencies: 199
-- Data for Name: requiresversion; Type: TABLE DATA; Schema: public; Owner: mapper
--

INSERT INTO public.requiresversion VALUES (1);

--
-- TOC entry 2918 (class 0 OID 16424)
-- Dependencies: 201
-- Data for Name: userids; Type: TABLE DATA; Schema: public; Owner: mapper
--

INSERT INTO public.userids VALUES ('_DefaultExperte', 0, 5, true, NULL, false, '0-2 0-3 1-2 1-3 2-3 2-2 3-2 3-3 5-5');
INSERT INTO public.userids VALUES ('_DefaultLabor', 3, 4, true, 'source_code like ''6%''', false, '3-1 3-4 3-5 5-4 4-1 4-2 4-5 5-5');
INSERT INTO public.userids VALUES ('_DefaultAlleRechte', 0, 5, false, NULL, false, '0-0 0-1 0-2 0-3 0-4 0-5 1-0 1-1 1-2 1-3 1-4 1-5 2-0 2-1 2-2 2-3 2-4 2-5 3-0 3-1 3-2 3-3 3-4 3-5 4-0 4-1 4-2 4-3 4-4 4-5 5-0 5-1 5-2 5-3 5-4 5-5');


--
-- TOC entry 2790 (class 2606 OID 16435)
-- Name: userids userids_pk; Type: CONSTRAINT; Schema: public; Owner: mapper
--

ALTER TABLE ONLY public.userids
    ADD CONSTRAINT userids_pk PRIMARY KEY (userid);


--
-- TOC entry 2926 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA public TO readonly;


--
-- TOC entry 2930 (class 0 OID 0)
-- Dependencies: 196
-- Name: TABLE expertlevel; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.expertlevel TO readonly;


--
-- TOC entry 2935 (class 0 OID 0)
-- Dependencies: 197
-- Name: TABLE log; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.log TO readonly;


--
-- TOC entry 2948 (class 0 OID 0)
-- Dependencies: 198
-- Name: TABLE mapping; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.mapping TO readonly;


--
-- TOC entry 2957 (class 0 OID 0)
-- Dependencies: 201
-- Name: TABLE userids; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.userids TO readonly;


--
-- TOC entry 2960 (class 0 OID 0)
-- Dependencies: 199
-- Name: TABLE requiresversion; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.requiresversion TO readonly;


--
-- TOC entry 2964 (class 0 OID 0)
-- Dependencies: 202
-- Name: TABLE sourceterms; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.sourceterms TO readonly;


--
-- TOC entry 2968 (class 0 OID 0)
-- Dependencies: 200
-- Name: TABLE terminfo; Type: ACL; Schema: public; Owner: mapper
--

GRANT SELECT ON TABLE public.terminfo TO readonly;


-- Completed on 2020-01-08 13:43:56

--
-- PostgreSQL database dump complete
--

